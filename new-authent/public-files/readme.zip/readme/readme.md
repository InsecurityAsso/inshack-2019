# How to login

1) Generate a totp code. The seed is the same 8 digit number than the safe code but base32 encoded (param HMAC-SHA1, 30s steps, 10 bytes secret)
2) Write it on a new document. It works great with Verdana or Hack, with font size between 60 and 100. 
3) Print it on our printer, it is very important to use our printer as we use the Document Colour Tracking Dots.
4) Scan the printed document, with at least 300 dpi and save it as a png. 
5) Use the scanned document to login. Sometimes our system does not recognize the result, please try again with another code

Note : You can find 2 printed document with their timestamps as filename as example.
Working remotly ? Might want to take a look at Deda for the printer part ;)